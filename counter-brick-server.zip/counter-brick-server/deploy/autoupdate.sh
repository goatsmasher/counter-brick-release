#!/usr/bin/env bash
# Counter Brick: look for a newer build in the release feed and install it. Run by a systemd timer
# (see setup-autoupdate.sh) once a minute, or by hand:  sudo /opt/counter-brick/deploy/autoupdate.sh
#
# The feed is a folder on the web holding two files:
#   latest.json                  {"build":"v32","zip":"counter-brick-server.zip","sha256":"<hex>"}
#   counter-brick-server.zip     the bundle made by tools/bundle.sh
# A build is installed only if it is NEWER than what is live and NEWER than any build already installed or rolled back here,
# and only if the download matches its checksum. Installing goes through update.sh, so every install is
# health-checked and rolls back by itself. A build that failed is not retried; ship a newer one.
# Your own manual rollback.sh is respected too: a build you rolled back from is not pushed again.
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$HERE/common.sh"
CONF="${CB_AUTOUPDATE_CONF:-/etc/counter-brick-autoupdate}"
[ -f "$CONF" ] && . "$CONF"
FEED="${CB_FEED_URL:-}"
need_root
[ -n "$FEED" ] || { echo "No feed address: set CB_FEED_URL in $CONF (setup-autoupdate.sh does this)."; exit 1; }
FEED="${FEED%/}"; SEEN="$APP/autoupdate.seen"; LOG="autoupdate:"
num() { echo "${1#v}" | grep -E '^[0-9]+$' || echo 0; }

TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
curl -fsS --max-time 20 -H 'Cache-Control: no-cache' "$FEED/latest.json?t=$(date +%s)" -o "$TMP/latest.json" 2>"$TMP/err" || { echo "$LOG feed not reachable ($(head -c 120 "$TMP/err")); will try again"; exit 0; }
field() { node -e 'try{const j=JSON.parse(require("fs").readFileSync(process.argv[1],"utf8"));process.stdout.write(String(j[process.argv[2]]||""))}catch(e){}' "$TMP/latest.json" "$1"; }
BUILD="$(field build)"; ZIPNAME="$(field zip)"; SUM="$(field sha256)"
[ -n "$BUILD" ] && [ -n "$ZIPNAME" ] && [ -n "$SUM" ] || { echo "$LOG latest.json is incomplete; ignoring"; exit 0; }
case "$ZIPNAME" in */*|*..*) echo "$LOG suspicious zip name; ignoring"; exit 0;; esac

LIVE="$(live_build)"; TOP="$(num "$LIVE")"
if [ -f "$SEEN" ]; then S="$(num "$(cat "$SEEN")")"; [ "$S" -gt "$TOP" ] && TOP="$S"; fi
if [ "$(num "$BUILD")" -le "$TOP" ]; then exit 0; fi     # nothing new (this is the quiet, normal case)

echo "$LOG $BUILD is newer than ${LIVE:-nothing} (already handled up to v$TOP): downloading"
curl -fsS --max-time 180 "$FEED/$ZIPNAME?t=$(date +%s)" -o "$TMP/b.zip" || { echo "$LOG download failed; will try again next minute"; exit 1; }
GOT="$(sha256sum "$TMP/b.zip" | cut -d' ' -f1)"
[ "$GOT" = "$SUM" ] || { echo "$LOG checksum mismatch (got $GOT, expected $SUM): NOT installing, will try again (the feed may still be updating)"; exit 1; }
command -v unzip >/dev/null || apt-get install -y unzip >/dev/null
mkdir "$TMP/x" && unzip -q "$TMP/b.zip" -d "$TMP/x" && [ -f "$TMP/x/counter-brick-server/deploy/update.sh" ] || { echo "$LOG bundle looks wrong; NOT installing"; exit 1; }
[ "$(page_build "$TMP/x/counter-brick-server/public/counter-brick.html")" = "$BUILD" ] || { echo "$LOG the page in the bundle is not $BUILD; NOT installing"; exit 1; }
echo "$BUILD" > "$SEEN"                                  # recorded just before installing: a build that fails to start is never retried
bash "$TMP/x/counter-brick-server/deploy/update.sh" && echo "$LOG $BUILD installed" || { echo "$LOG $BUILD failed to start and was rolled back; waiting for a newer build"; exit 1; }
