#!/usr/bin/env bash
# Counter Brick: copy player feedback to a private GitHub repo (run once on the server).
#   sudo bash /opt/counter-brick/deploy/setup-feedback.sh <owner>/<repo>
#   sudo bash /opt/counter-brick/deploy/setup-feedback.sh off        (stop copying; messages stay on the server)
# It asks for a GitHub token (typed input is hidden) that can write to that one repo, checks it works, stores it
# in /etc/counter-brick/feedback.env (readable by root only) and restarts the game server. Feedback sent before
# this was set up is copied too. Messages are always kept on the server in /opt/counter-brick/data/feedback.jsonl.
set -euo pipefail
[ "$(id -u)" = 0 ] || { echo "Run this with sudo."; exit 1; }
DROP=/etc/systemd/system/counter-brick.service.d/feedback.conf
ENVF=/etc/counter-brick/feedback.env
if [ "${1:-}" = off ]; then
  rm -f "$DROP" "$ENVF"; systemctl daemon-reload; systemctl restart counter-brick
  echo "Feedback copying is off. Messages are still saved on the server."; exit 0
fi
REPO="${1:-}"
[[ "$REPO" =~ ^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$ ]] || { echo "Usage: sudo bash setup-feedback.sh <owner>/<repo>   (or: off)"; exit 1; }
read -rsp "Paste the GitHub token for $REPO (nothing will show as you paste), then press Enter: " TOKEN; echo
TOKEN="$(printf '%s' "$TOKEN" | tr -d '[:space:]')"
[ -n "$TOKEN" ] || { echo "No token given."; exit 1; }
CODE="$(curl -s -o /tmp/cb-gh-check -w '%{http_code}' -H "Authorization: Bearer $TOKEN" -H 'User-Agent: counter-brick-server' "https://api.github.com/repos/$REPO" || true)"
if [ "$CODE" != 200 ]; then
  echo "GitHub answered $CODE for $REPO. Check the repo name, and that the token was given access to this repo."; rm -f /tmp/cb-gh-check; exit 1
fi
grep -q '"push": *true' /tmp/cb-gh-check || { echo "The token can read $REPO but cannot write to it. Give it 'Contents: Read and write'."; rm -f /tmp/cb-gh-check; exit 1; }
rm -f /tmp/cb-gh-check
mkdir -p /etc/counter-brick "$(dirname "$DROP")"
( umask 077; printf 'CB_FEEDBACK_REPO=%s\nCB_FEEDBACK_TOKEN=%s\n' "$REPO" "$TOKEN" > "$ENVF" )
printf '[Service]\nEnvironmentFile=-%s\n' "$ENVF" > "$DROP"
systemctl daemon-reload; systemctl restart counter-brick
sleep 4
echo "Feedback will be copied to github.com/$REPO (folder feedback/)."
curl -fsS http://127.0.0.1:8080/health | grep -o '"feedback":{[^}]*}' || true
