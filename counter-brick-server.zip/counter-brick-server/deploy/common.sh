# Shared by update.sh and rollback.sh (sourced, not run). Settings can be overridden from the environment,
# which is also how the scripts are tested on a machine that is not the server.
APP="${CB_APP:-/opt/counter-brick}"
SERVICE="${CB_SERVICE-counter-brick}"            # empty = no systemd service to restart
HEALTH="${CB_HEALTH:-http://127.0.0.1:8080/health}"
KEEP="${CB_KEEP:-8}"                              # how many previous versions to keep for rollback
OWNER="${CB_OWNER-counterbrick}"                  # empty = leave file ownership alone
FILES="server.js package.json package-lock.json public/counter-brick.html"

need_root() { if [ -z "${CB_APP:-}" ] && [ "$(id -u)" != 0 ]; then echo "Run this with sudo."; exit 1; fi; }
page_build() { grep -o 'Build v[0-9]*' "$1" 2>/dev/null | head -1 | cut -d' ' -f2 || true; }
live_build() { page_build "$APP/public/counter-brick.html"; }
restart_service() { if [ -n "$SERVICE" ]; then systemctl restart "$SERVICE"; else echo "(no service to restart)"; fi; }
fix_owner() { if [ -n "$OWNER" ]; then chown -R "$OWNER:$OWNER" "$APP"; fi; }

# healthy <expected build>: the server answers /health and is serving that build. Waits up to ~20 s.
healthy() {
  local want="$1" body i
  for i in $(seq 1 20); do
    body="$(curl -fsS --max-time 3 "$HEALTH" 2>/dev/null || true)"
    if [ -n "$body" ] && echo "$body" | grep -q '"ok":true' && { [ -z "$want" ] || echo "$body" | grep -q "\"build\":\"$want\""; }; then
      echo "healthy: $body"; return 0
    fi
    sleep 1
  done
  echo "NOT healthy after 20 s (wanted build ${want:-any}); last answer: ${body:-none}"; return 1
}

# restore_release <dir>: put a saved copy back and restart.
restore_release() {
  local dir="$1" relock=0
  [ -d "$dir" ] || { echo "No such saved version: $dir"; return 1; }
  cmp -s "$dir/package-lock.json" "$APP/package-lock.json" 2>/dev/null || relock=1
  for f in $FILES; do [ -f "$dir/$f" ] && { mkdir -p "$APP/$(dirname "$f")"; cp "$dir/$f" "$APP/$f"; }; done
  if [ "$relock" = 1 ] && [ -z "${CB_NO_NPM:-}" ]; then (cd "$APP" && npm ci --omit=dev --no-audit --no-fund); fi
  fix_owner; restart_service
}
