#!/usr/bin/env bash
# Counter Brick: go back to an earlier version.
#   sudo /opt/counter-brick/deploy/rollback.sh          -> list saved versions
#   sudo /opt/counter-brick/deploy/rollback.sh last     -> the version that was live before the latest update
#   sudo /opt/counter-brick/deploy/rollback.sh <name>   -> a specific one from the list
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. "$HERE/common.sh"
need_root
mapfile -t LIST < <(ls -1 "$APP/releases" 2>/dev/null | sort)
if [ "${1:-}" = "" ] || [ ${#LIST[@]} -eq 0 ]; then
  echo "Live now: $(live_build)"; echo "Saved versions (oldest first; the name ends with the build it holds):"
  [ ${#LIST[@]} -eq 0 ] && echo "  (none yet)" || printf '  %s\n' "${LIST[@]}"
  echo; echo "Roll back with:  sudo $APP/deploy/rollback.sh last   (or a name from above)"; exit 0
fi
if [ "$1" = last ]; then PICK="${LIST[${#LIST[@]}-1]}"; else PICK="$1"; fi
[ -d "$APP/releases/$PICK" ] || { echo "No saved version called $PICK"; exit 1; }
WANT="${PICK##*_}"; [ "$WANT" = none ] && WANT=""
# keep a copy of what is live now so the rollback itself can be undone
KEEPREL="$APP/releases/$(date +%Y%m%d-%H%M%S)_$(live_build)"; mkdir -p "$KEEPREL/public"
for f in $FILES; do [ -f "$APP/$f" ] && cp "$APP/$f" "$KEEPREL/$f"; done
echo "==> restoring $PICK"
restore_release "$APP/releases/$PICK"
healthy "$WANT" && echo "==> DONE: build ${WANT:-?} is live again"
