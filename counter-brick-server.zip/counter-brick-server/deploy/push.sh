#!/usr/bin/env bash
# Counter Brick: send a new version to the AWS server and make it live (Mac / Linux / Git Bash).
#   bash push.sh [path/to/counter-brick-server.zip]
# With no argument it uses the newest counter-brick-server*.zip in ~/Downloads or the current folder.
# First run asks for the server address and saves it to ~/.counter-brick-push (edit or delete it to change).
# The server side (update.sh) saves the old version, installs the new one, checks it is healthy and
# rolls back by itself if it is not.
set -euo pipefail
CONF="$HOME/.counter-brick-push"
[ -f "$CONF" ] && . "$CONF"
if [ -z "${CB_HOST:-}" ]; then
  read -rp "Server address (domain or IP): " CB_HOST
  read -rp "SSH user [ubuntu]: " CB_USER; CB_USER="${CB_USER:-ubuntu}"
  read -rp "Path to your SSH key (.pem), blank if your ssh agent has it: " CB_KEY
  read -rp "Public game address to check afterwards (e.g. https://counter-brick.example.com), blank to skip: " CB_URL
  printf 'CB_HOST=%q\nCB_USER=%q\nCB_KEY=%q\nCB_URL=%q\n' "$CB_HOST" "$CB_USER" "${CB_KEY:-}" "${CB_URL:-}" > "$CONF"; echo "Saved to $CONF"
fi
ZIP="${1:-}"
if [ -z "$ZIP" ]; then ZIP="$(ls -t "$HOME"/Downloads/counter-brick-server*.zip ./counter-brick-server*.zip 2>/dev/null | head -1 || true)"; fi
[ -f "$ZIP" ] || { echo "Cannot find counter-brick-server.zip. Pass its path:  bash push.sh path/to/counter-brick-server.zip"; exit 1; }
SSH=(ssh -o StrictHostKeyChecking=accept-new -o ConnectTimeout=15); SCP=(scp -o StrictHostKeyChecking=accept-new -o ConnectTimeout=15)
if [ -n "${CB_KEY:-}" ]; then SSH+=(-i "$CB_KEY"); SCP+=(-i "$CB_KEY"); fi
echo "==> sending $(basename "$ZIP") ($(du -h "$ZIP" | cut -f1)) to $CB_USER@$CB_HOST"
"${SCP[@]}" "$ZIP" "$CB_USER@$CB_HOST:cb-push.zip"
echo "==> installing on the server"
"${SSH[@]}" "$CB_USER@$CB_HOST" 'set -e; command -v unzip >/dev/null || sudo apt-get install -y unzip >/dev/null; rm -rf ~/cb-push && mkdir ~/cb-push && unzip -q -o ~/cb-push.zip -d ~/cb-push && sudo bash ~/cb-push/counter-brick-server/deploy/update.sh; R=$?; rm -rf ~/cb-push ~/cb-push.zip; exit $R'
if [ -n "${CB_URL:-}" ]; then echo "==> checking ${CB_URL%/}/health from here"; curl -fsS --max-time 10 "${CB_URL%/}/health" && echo; fi
echo "Done. Players already in a game keep playing; everyone else gets the new build on their next page load."
