#!/usr/bin/env bash
# Counter Brick: put a new build live, safely.
#   sudo bash deploy/update.sh          (run from the unpacked bundle; push.ps1 / push.sh do this for you)
#
# 1. saves what is live now under /opt/counter-brick/releases/ (the last 8 are kept)
# 2. installs the new page, and the new server + dependencies if server.js or the lockfile changed
# 3. restarts the service only if the server changed (a new page alone needs no restart)
# 4. asks /health which build is being served; if it is not the new one within ~20 s, puts the previous
#    version back automatically and exits with an error
# Rooms in progress are told the server is restarting.
set -euo pipefail
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
. "$SRC/deploy/common.sh"
need_root
[ -f "$SRC/public/counter-brick.html" ] && [ -f "$SRC/server.js" ] || { echo "Run from the unpacked bundle (server.js and public/counter-brick.html next to deploy/)."; exit 1; }
[ -d "$APP" ] || { echo "$APP does not exist: run deploy/setup.sh first."; exit 1; }
NEW="$(page_build "$SRC/public/counter-brick.html")"
[ -n "$NEW" ] || { echo "The page has no build number: refusing to deploy it."; exit 1; }
grep -q "window.__bs" "$SRC/public/counter-brick.html" && { echo "That page is a developer build: refusing to deploy it."; exit 1; }
OLD="$(live_build)"; OLD="${OLD:-none}"
echo "==> $OLD  ->  $NEW"

REL="$APP/releases/$(date +%Y%m%d-%H%M%S)_$OLD"
mkdir -p "$REL/public"
for f in $FILES; do [ -f "$APP/$f" ] && cp "$APP/$f" "$REL/$f"; done
echo "==> saved the current version as $(basename "$REL")"

RESTART=0
if ! cmp -s "$SRC/server.js" "$APP/server.js" || ! cmp -s "$SRC/package-lock.json" "$APP/package-lock.json"; then RESTART=1; fi
mkdir -p "$APP/public" "$APP/deploy"
cp "$SRC/server.js" "$SRC/package.json" "$SRC/package-lock.json" "$APP/"
cp "$SRC/public/counter-brick.html" "$APP/public/counter-brick.html"
cp "$SRC"/deploy/*.sh "$APP/deploy/"; chmod +x "$APP"/deploy/*.sh
if [ "$RESTART" = 1 ]; then
  [ -n "${CB_NO_NPM:-}" ] || (cd "$APP" && npm ci --omit=dev --no-audit --no-fund)
  fix_owner; restart_service; echo "==> server updated and restarted"
else
  fix_owner; echo "==> new page is live (server unchanged, no restart)"
fi

if healthy "$NEW"; then
  ls -1d "$APP"/releases/*/ 2>/dev/null | sort | head -n "-$KEEP" | while read -r d; do rm -rf "$d"; done
  echo "==> DONE: $NEW is live"
else
  echo "==> the new version did not come up: putting $OLD back"
  restore_release "$REL" || true
  if healthy "${OLD/none/}"; then rm -rf "$REL"; echo "==> ROLLED BACK to $OLD. The new build was NOT deployed."; else echo "==> rollback did not report healthy either: check 'journalctl -u counter-brick -n 50'"; fi
  exit 1
fi
