#!/usr/bin/env bash
# Counter Brick: one-shot server setup for a fresh Ubuntu machine (Lightsail or EC2).
#
#   sudo bash deploy/setup.sh                    -> plain http://<server-ip>/   (fine for a first test)
#   sudo bash deploy/setup.sh play.example.com   -> https://play.example.com/  (certificate is automatic)
#
# Installs Node.js and Caddy, copies the server to /opt/counter-brick, runs it as a service that
# restarts on failure and on reboot, and puts Caddy in front of it for HTTPS and WebSockets.
# Safe to run again: it updates the files and restarts the service.
set -euo pipefail
DOMAIN="${1:-}"
APP=/opt/counter-brick
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

[ "$(id -u)" = 0 ] || { echo "Run this with sudo."; exit 1; }
[ -f "$SRC/server.js" ] && [ -f "$SRC/public/counter-brick.html" ] || { echo "Run from the unpacked bundle: server.js and public/counter-brick.html must sit next to deploy/."; exit 1; }
export DEBIAN_FRONTEND=noninteractive

echo "==> packages"
apt-get update -y
apt-get install -y curl ca-certificates gnupg debian-keyring debian-archive-keyring apt-transport-https

if ! command -v node >/dev/null || [ "$(node -p 'process.versions.node.split(".")[0]')" -lt 18 ]; then
  echo "==> Node.js"
  curl -fsSL https://deb.nodesource.com/setup_24.x | bash -
  apt-get install -y nodejs
fi

if ! command -v caddy >/dev/null; then
  echo "==> Caddy"
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor --yes -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' > /etc/apt/sources.list.d/caddy-stable.list
  chmod o+r /usr/share/keyrings/caddy-stable-archive-keyring.gpg /etc/apt/sources.list.d/caddy-stable.list
  apt-get update -y
  apt-get install -y caddy
fi

echo "==> game server in $APP"
id counterbrick >/dev/null 2>&1 || useradd --system --home "$APP" --shell /usr/sbin/nologin counterbrick
mkdir -p "$APP"
cp "$SRC/server.js" "$SRC/package.json" "$SRC/package-lock.json" "$APP/"
rm -rf "$APP/public"; cp -r "$SRC/public" "$APP/public"
(cd "$APP" && npm ci --omit=dev --no-audit --no-fund)
chown -R counterbrick:counterbrick "$APP"

cat > /etc/systemd/system/counter-brick.service <<UNIT
[Unit]
Description=Counter Brick game server
After=network-online.target
Wants=network-online.target

[Service]
User=counterbrick
WorkingDirectory=$APP
Environment=PORT=8080
Environment=HOST=127.0.0.1
Environment=NODE_ENV=production
ExecStart=$(command -v node) $APP/server.js
Restart=always
RestartSec=2
NoNewPrivileges=true
ProtectSystem=full
PrivateTmp=true

[Install]
WantedBy=multi-user.target
UNIT

echo "==> Caddy in front (${DOMAIN:-plain http on port 80})"
cat > /etc/caddy/Caddyfile <<CADDY
# Counter Brick. With a domain name here Caddy fetches and renews the HTTPS certificate by itself.
${DOMAIN:-:80} {
	reverse_proxy 127.0.0.1:8080
}
CADDY

systemctl daemon-reload
systemctl enable counter-brick >/dev/null
systemctl restart counter-brick
systemctl enable caddy >/dev/null
systemctl restart caddy

sleep 2
if curl -fsS http://127.0.0.1:8080/health >/dev/null; then
  echo
  echo "Counter Brick is up."
  if [ -n "$DOMAIN" ]; then echo "  Play:   https://$DOMAIN/"; else echo "  Play:   http://<this server's public IP>/"; fi
  echo "  Health: curl http://127.0.0.1:8080/health"
  echo "  Logs:   journalctl -u counter-brick -f"
else
  echo "The game server did not answer. Look at: journalctl -u counter-brick -n 50"; exit 1
fi
