#!/usr/bin/env bash
# Counter Brick: turn on automatic updates (run once on the server).
#   sudo bash /opt/counter-brick/deploy/setup-autoupdate.sh https://raw.githubusercontent.com/<owner>/<repo>/main
#   sudo bash /opt/counter-brick/deploy/setup-autoupdate.sh off          (turn it off again)
# From then on the server checks the feed once a minute and installs any newer build by itself.
set -euo pipefail
[ "$(id -u)" = 0 ] || { echo "Run this with sudo."; exit 1; }
APP=/opt/counter-brick
if [ "${1:-}" = off ]; then systemctl disable --now counter-brick-autoupdate.timer 2>/dev/null || true; echo "Automatic updates are off."; exit 0; fi
FEED="${1:-}"; [ -n "$FEED" ] || { echo "Usage: sudo bash setup-autoupdate.sh <feed address>   (or: off)"; exit 1; }
curl -fsS --max-time 20 "${FEED%/}/latest.json" > /dev/null || { echo "Cannot read ${FEED%/}/latest.json: check the address (and that something has been published there)."; exit 1; }
printf 'CB_FEED_URL=%q\n' "${FEED%/}" > /etc/counter-brick-autoupdate; chmod 600 /etc/counter-brick-autoupdate
cat > /etc/systemd/system/counter-brick-autoupdate.service <<UNIT
[Unit]
Description=Counter Brick: install a newer build if the feed has one
After=network-online.target
[Service]
Type=oneshot
ExecStart=$APP/deploy/autoupdate.sh
UNIT
cat > /etc/systemd/system/counter-brick-autoupdate.timer <<UNIT
[Unit]
Description=Counter Brick: check for a new build every minute
[Timer]
OnBootSec=60
OnUnitActiveSec=60
AccuracySec=10
[Install]
WantedBy=timers.target
UNIT
chmod +x "$APP"/deploy/*.sh
systemctl daemon-reload; systemctl enable --now counter-brick-autoupdate.timer
echo "Automatic updates are ON, watching ${FEED%/}"
echo "See what it did:  journalctl -u counter-brick-autoupdate -n 20      Turn off:  sudo bash $APP/deploy/setup-autoupdate.sh off"
