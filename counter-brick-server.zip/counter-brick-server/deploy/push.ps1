# Counter Brick: send a new version to the AWS server and make it live (Windows PowerShell).
#   .\push.ps1 [path\to\counter-brick-server.zip]
# With no argument it uses the newest counter-brick-server*.zip in your Downloads folder or this folder.
# First run asks for the server address and saves it to %USERPROFILE%\.counter-brick-push.json.
# Uses the ssh and scp that ship with Windows 10/11 (Settings > Apps > Optional features > OpenSSH Client).
# The server side (update.sh) saves the old version, installs the new one, checks it is healthy and
# rolls back by itself if it is not.
param([string]$Zip = "")
$ErrorActionPreference = "Stop"
$conf = Join-Path $HOME ".counter-brick-push.json"
if (Test-Path $conf) { $c = Get-Content $conf -Raw | ConvertFrom-Json } else {
  $c = [pscustomobject]@{ Host = ""; User = "ubuntu"; Key = ""; Url = "" }
  $c.Host = Read-Host "Server address (domain or IP)"
  $u = Read-Host "SSH user [ubuntu]"; if ($u) { $c.User = $u }
  $c.Key = Read-Host "Full path to your SSH key (.pem), blank if ssh already knows it"
  $c.Url = Read-Host "Public game address to check afterwards (e.g. https://counter-brick.example.com), blank to skip"
  $c | ConvertTo-Json | Set-Content $conf; Write-Host "Saved to $conf"
}
if (-not $Zip) {
  $Zip = Get-ChildItem -Path (Join-Path $HOME "Downloads\counter-brick-server*.zip"), ".\counter-brick-server*.zip" -ErrorAction SilentlyContinue |
    Sort-Object LastWriteTime -Descending | Select-Object -First 1 -ExpandProperty FullName
}
if (-not $Zip -or -not (Test-Path $Zip)) { throw "Cannot find counter-brick-server.zip. Pass its path:  .\push.ps1 C:\path\to\counter-brick-server.zip" }
foreach ($t in "ssh", "scp") { if (-not (Get-Command $t -ErrorAction SilentlyContinue)) { throw "$t not found. Install the OpenSSH Client (Settings > Apps > Optional features)." } }
$opts = @("-o", "StrictHostKeyChecking=accept-new", "-o", "ConnectTimeout=15")
if ($c.Key) { $opts += @("-i", $c.Key) }
$dest = "$($c.User)@$($c.Host)"
$mb = [math]::Round((Get-Item $Zip).Length / 1MB, 1)
Write-Host "==> sending $(Split-Path $Zip -Leaf) ($mb MB) to $dest"
& scp @opts $Zip "${dest}:cb-push.zip"
if ($LASTEXITCODE -ne 0) { throw "Upload failed (scp exit $LASTEXITCODE). Check the address, user and key." }
Write-Host "==> installing on the server"
$remote = 'set -e; command -v unzip >/dev/null || sudo apt-get install -y unzip >/dev/null; rm -rf ~/cb-push && mkdir ~/cb-push && unzip -q -o ~/cb-push.zip -d ~/cb-push && sudo bash ~/cb-push/counter-brick-server/deploy/update.sh; R=$?; rm -rf ~/cb-push ~/cb-push.zip; exit $R'
& ssh @opts $dest $remote
if ($LASTEXITCODE -ne 0) { throw "The server did not take the new version (exit $LASTEXITCODE). Read the lines above: if it says ROLLED BACK, the old version is still live." }
if ($c.Url) { Write-Host "==> checking $($c.Url)/health from here"; try { (Invoke-WebRequest -UseBasicParsing -TimeoutSec 10 ($c.Url.TrimEnd('/') + "/health")).Content } catch { Write-Warning "Could not reach $($c.Url): $_" } }
Write-Host "Done. Players already in a game keep playing; everyone else gets the new build on their next page load."
