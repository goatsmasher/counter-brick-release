#!/usr/bin/env node
/* Counter Brick game server.
   One small Node process that does three jobs:
     1. serves the game itself (public/counter-brick.html) over HTTP
     2. runs the lobby: rooms with 4-letter codes, up to 10 players each
     3. relays game traffic between the host (whose browser runs the match) and the other players
   The server never simulates the game; the room host's browser is authoritative.

   Run:  npm install && node server.js
   Env:  PORT (8080) · HOST (0.0.0.0) · CB_PUBLIC (folder holding counter-brick.html, default ./public)
   Health:  GET /health -> {ok, build, rooms, players, uptime, feedback}   (build = the game version being served, e.g. "v32")
   Feedback: POST /feedback {cat, rating, name, text, ctx} from the in-game form. Stored in CB_DATA/feedback.jsonl
             (default ./data) and, when CB_FEEDBACK_REPO + CB_FEEDBACK_TOKEN are set, copied to that GitHub repo as
             feedback/YYYY-MM/<time>_<id>.json (deploy/setup-feedback.sh sets this up). No IP address is stored.
*/
const http = require('http');
const path = require('path');
const fs = require('fs');
const zlib = require('zlib');
const crypto = require('crypto');
const { WebSocketServer } = require('ws');

const PORT = +(process.env.PORT || 8080);
const MAX_ROOMS = 200, MAX_PLAYERS = 10, MAX_MSG = 256 * 1024;
const PUBLIC = process.env.CB_PUBLIC || path.join(__dirname, 'public');
const gzCache = new Map();          // path -> { m: mtime, z: gzipped bytes }
const started = Date.now();
let buildMemo = { m: 0, v: '' };     // which game version public/counter-brick.html is (re-read when the file changes)
function buildTag() {
  try {
    const f = path.join(PUBLIC, 'counter-brick.html'), m = fs.statSync(f).mtimeMs;
    if (m !== buildMemo.m) { const hit = /Build (v\d+)/.exec(fs.readFileSync(f, 'utf8')); buildMemo = { m, v: hit ? hit[1] : 'unknown' }; }
    return buildMemo.v;
  } catch (e) { return 'missing'; }
}

/* ---------------- static files ---------------- */
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json' };
const server = http.createServer((req, res) => {
  const u = (req.url || '/').split('?')[0];
  if (u === '/feedback') return feedbackRoute(req, res);
  if (u === '/health') {
    let players = 0; for (const r of rooms.values()) players += r.all().length;
    res.writeHead(200, { 'content-type': 'application/json', 'access-control-allow-origin': '*' });
    return res.end(JSON.stringify({ ok: true, game: 'counter-brick', build: buildTag(), feedback: fbStatus(), rooms: rooms.size, players, uptime: Math.round((Date.now() - started) / 1000) }));
  }
  let f = u === '/' ? '/counter-brick.html' : u;
  f = path.normalize(f).replace(/^(\.\.[\/\\])+/, '');
  const full = path.join(PUBLIC, f);
  if (!full.startsWith(PUBLIC)) { res.writeHead(403); return res.end(); }
  fs.stat(full, (e0, st) => {
    if (e0 || !st.isFile()) { res.writeHead(404, { 'content-type': 'text/plain' }); return res.end('not found'); }
    fs.readFile(full, (err, data) => {
      if (err) { res.writeHead(404, { 'content-type': 'text/plain' }); return res.end('not found'); }
      const type = MIME[path.extname(full)] || 'application/octet-stream';
      const head = { 'content-type': type, 'cache-control': 'no-cache' };
      // the game is one 1.3 MB page: gzip it once and keep the result
      if (/\bgzip\b/.test(req.headers['accept-encoding'] || '') && /html|javascript|css|json/.test(type)) {
        let c = gzCache.get(full);
        if (!c || c.m !== st.mtimeMs) { c = { m: st.mtimeMs, z: zlib.gzipSync(data, { level: 9 }) }; gzCache.set(full, c); }
        head['content-encoding'] = 'gzip'; head.vary = 'accept-encoding';
        res.writeHead(200, head); return res.end(c.z);
      }
      res.writeHead(200, head); res.end(data);
    });
  });
});

/* ---------------- player feedback ---------------- */
const DATA = process.env.CB_DATA || path.join(__dirname, 'data');
const FB_FILE = path.join(DATA, 'feedback.jsonl'), FB_SYNCED = path.join(DATA, 'feedback-synced.txt');
const GH = { repo: process.env.CB_FEEDBACK_REPO || '', token: process.env.CB_FEEDBACK_TOKEN || '', api: process.env.CB_GITHUB_API || 'https://api.github.com' };
const FB_CATS = ['bug', 'idea', 'balance', 'map', 'online', 'other'];
const FB_LIMIT = +(process.env.CB_FEEDBACK_LIMIT || 5);   // messages per address per 10 minutes
const fbHits = new Map();
const fb = { stored: 0, synced: 0, lastError: '' };
try { fb.stored = fs.readFileSync(FB_FILE, 'utf8').split('\n').filter(Boolean).length; } catch (e) {}
try { fb.synced = fs.readFileSync(FB_SYNCED, 'utf8').split('\n').filter(Boolean).length; } catch (e) {}
function fbStatus() { return { stored: fb.stored, github: GH.repo && GH.token ? (fb.lastError ? 'error: ' + fb.lastError : fb.stored - fb.synced > 0 ? `pending ${fb.stored - fb.synced}` : 'up to date') : 'off' }; }
const clip = (v, n) => String(v == null ? '' : v).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '').slice(0, n);
function fbCtx(c) {   // only these facts about the player's game travel with a message
  c = c && typeof c === 'object' ? c : {}; const o = {};
  for (const k of ['build', 'map', 'mode', 'state', 'screen', 'ua']) if (c[k] != null) o[k] = clip(c[k], k === 'ua' ? 180 : 40);
  for (const k of ['ping', 'fps']) if (Number.isFinite(+c[k])) o[k] = Math.round(+c[k]);
  for (const k of ['online', 'safe', 'touch']) if (c[k] != null) o[k] = !!c[k];
  return o;
}
function feedbackRoute(req, res) {
  const cors = { 'access-control-allow-origin': '*', 'access-control-allow-methods': 'POST, OPTIONS', 'access-control-allow-headers': 'content-type' };
  const reply = (code, o) => { if (res.headersSent) return; res.writeHead(code, Object.assign({ 'content-type': 'application/json' }, cors)); res.end(JSON.stringify(o)); };
  if (req.method === 'OPTIONS') { res.writeHead(204, cors); return res.end(); }
  if (req.method !== 'POST') return reply(405, { ok: false, error: 'Send feedback with POST.' });
  const ip = String(req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();
  const now = Date.now(), hits = (fbHits.get(ip) || []).filter(t => now - t < 600e3);
  if (hits.length >= FB_LIMIT) return reply(429, { ok: false, error: 'That is a lot of messages. Try again in a few minutes.' });
  let body = '', big = false;
  req.on('data', c => { if (big) return; body += c; if (body.length > 16384) { big = true; reply(413, { ok: false, error: 'That message is too long.' }); req.resume(); } });
  req.on('end', () => {
    if (big) return;
    let m; try { m = JSON.parse(body); } catch (e) { return reply(400, { ok: false, error: 'Could not read that message.' }); }
    if (!m || typeof m !== 'object') return reply(400, { ok: false, error: 'Could not read that message.' });
    if (m.website) return reply(200, { ok: true });   // honeypot field: bots fill it, people never see it
    const text = clip(m.text, 4000).trim();
    if (text.length < 3) return reply(400, { ok: false, error: 'Write a little more first.' });
    hits.push(now); fbHits.set(ip, hits);
    const r = m.rating | 0;
    const e = { id: now.toString(36) + crypto.randomBytes(3).toString('hex'), at: new Date(now).toISOString(), build: buildTag(),
      cat: FB_CATS.includes(m.cat) ? m.cat : 'other', rating: r >= 1 && r <= 5 ? r : null, name: clip(m.name, 24).trim() || null, text, ctx: fbCtx(m.ctx) };
    try { fs.mkdirSync(DATA, { recursive: true }); fs.appendFileSync(FB_FILE, JSON.stringify(e) + '\n'); }
    catch (err) { console.error('feedback: cannot write', err.message); return reply(500, { ok: false, error: 'The server could not save it. Please try later.' }); }
    fb.stored++; console.log(`feedback ${e.id} (${e.cat}) stored`);
    reply(200, { ok: true, id: e.id }); fbSyncSoon(800);
  });
}
// copy stored messages to GitHub, oldest first; anything that fails waits for the next pass
let fbSyncing = false, fbTimer = null;
function fbSyncSoon(ms) { if (!GH.repo || !GH.token) return; clearTimeout(fbTimer); fbTimer = setTimeout(fbSync, ms); }
async function fbSync() {
  if (fbSyncing) return; fbSyncing = true;
  try {
    const done = new Set(fs.existsSync(FB_SYNCED) ? fs.readFileSync(FB_SYNCED, 'utf8').split('\n').filter(Boolean) : []);
    const all = fs.existsSync(FB_FILE) ? fs.readFileSync(FB_FILE, 'utf8').split('\n').filter(Boolean).map(l => { try { return JSON.parse(l); } catch (x) { return null; } }).filter(Boolean) : [];
    for (const e of all) {
      if (done.has(e.id)) continue;
      const file = `feedback/${e.at.slice(0, 7)}/${e.at.replace(/[:.]/g, '-')}_${e.id}.json`;
      const r = await fetch(`${GH.api}/repos/${GH.repo}/contents/${file}`, { method: 'PUT', signal: AbortSignal.timeout(15000),
        headers: { authorization: `Bearer ${GH.token}`, accept: 'application/vnd.github+json', 'user-agent': 'counter-brick-server', 'content-type': 'application/json' },
        body: JSON.stringify({ message: `Feedback: ${e.cat} (${e.build})`, content: Buffer.from(JSON.stringify(e, null, 2) + '\n').toString('base64') }) });
      if (r.status !== 201 && r.status !== 200 && r.status !== 422) { fb.lastError = 'GitHub answered ' + r.status; console.error('feedback sync: ' + fb.lastError); break; }
      fs.appendFileSync(FB_SYNCED, e.id + '\n'); done.add(e.id); fb.synced = done.size; fb.lastError = '';
    }
  } catch (err) { fb.lastError = err.message.slice(0, 80); console.error('feedback sync:', err.message); }
  fbSyncing = false;
}
if (GH.repo && GH.token) { fbSyncSoon(3000); setInterval(() => fbSyncSoon(0), 300e3).unref(); }

/* ---------------- rooms ---------------- */
const rooms = new Map();            // code -> Room
const CODE_CHARS = 'ABCDEFGHJKMNPQRSTUVWXYZ';   // no I/L/O/0/1 lookalikes
function newCode() {
  for (let tries = 0; tries < 50; tries++) {
    let c = ''; for (let i = 0; i < 4; i++) c += CODE_CHARS[(Math.random() * CODE_CHARS.length) | 0];
    if (!rooms.has(c)) return c;
  }
  return null;
}
class Room {
  constructor(code, host) {
    this.code = code; this.host = host; this.clients = new Map(); this.nextId = 2; this.started = false; this.madeAt = Date.now();
  }
  all() { return [this.host, ...this.clients.values()].filter(w => w && w.readyState === 1); }
  roster() { return { t: 'roster', players: [{ id: 1, name: this.host.cbName }, ...[...this.clients.values()].map(w => ({ id: w.cbId, name: w.cbName }))], started: this.started }; }
  castRoster() { const r = JSON.stringify(this.roster()); for (const w of this.all()) w.send(r); }
  close(reason) {
    for (const w of this.all()) { try { w.send(JSON.stringify({ t: 'end', reason })); } catch (e) {} try { w.close(); } catch (e) {} }
    rooms.delete(this.code);
  }
}
const cleanName = s => String(s || '').replace(/[^\w \-'.]/g, '').trim().slice(0, 14) || 'Player';

/* ---------------- websocket ---------------- */
const wss = new WebSocketServer({ server, path: '/ws', maxPayload: MAX_MSG });
wss.on('connection', ws => {
  ws.cbAlive = true; ws.cbRoom = null; ws.cbId = 0; ws.cbName = '';
  ws.on('pong', () => { ws.cbAlive = true; });
  ws.on('message', raw => {
    let m; try { m = JSON.parse(raw); } catch (e) { return; }
    const room = ws.cbRoom;
    switch (m.t) {
      case 'host': {
        if (ws.cbRoom) return;
        if (rooms.size >= MAX_ROOMS) return ws.send(JSON.stringify({ t: 'err', why: 'The server is full right now' }));
        const code = newCode(); if (!code) return ws.send(JSON.stringify({ t: 'err', why: 'No room codes free' }));
        ws.cbName = cleanName(m.name); ws.cbId = 1;
        const r = new Room(code, ws); rooms.set(code, r); ws.cbRoom = r;
        ws.send(JSON.stringify({ t: 'hosted', code, id: 1 })); r.castRoster();
        break;
      }
      case 'join': {
        if (ws.cbRoom) return;
        const r = rooms.get(String(m.code || '').toUpperCase().trim());
        if (!r) return ws.send(JSON.stringify({ t: 'err', why: 'No room with that code' }));
        if (r.started) return ws.send(JSON.stringify({ t: 'err', why: 'That match has already started' }));
        if (r.all().length >= MAX_PLAYERS) return ws.send(JSON.stringify({ t: 'err', why: 'That room is full' }));
        ws.cbName = cleanName(m.name); ws.cbId = r.nextId++;
        r.clients.set(ws.cbId, ws); ws.cbRoom = r;
        ws.send(JSON.stringify({ t: 'joined', code: r.code, id: ws.cbId }));
        r.castRoster();
        break;
      }
      case 'to':      // client -> host
        if (room && ws !== room.host && room.host.readyState === 1) room.host.send(JSON.stringify({ t: 'from', id: ws.cbId, d: m.d }));
        break;
      case 'cast':    // host -> every client
        if (room && ws === room.host) { const s = JSON.stringify({ t: 'd', d: m.d }); for (const w of room.clients.values()) if (w.readyState === 1) w.send(s); }
        break;
      case 'one':     // host -> one client
        if (room && ws === room.host) { const w = room.clients.get(m.id); if (w && w.readyState === 1) w.send(JSON.stringify({ t: 'd', d: m.d })); }
        break;
      case 'start':   // host locks the room; late joins bounce
        if (room && ws === room.host) { room.started = true; room.castRoster(); }
        break;
      case 'ping': ws.send(JSON.stringify({ t: 'pong', n: m.n })); break;
    }
  });
  ws.on('close', () => {
    const r = ws.cbRoom; if (!r) return;
    if (ws === r.host) r.close('The host left');
    else { r.clients.delete(ws.cbId); if (r.host.readyState === 1) r.host.send(JSON.stringify({ t: 'left', id: ws.cbId })); r.castRoster(); }
  });
});
// keepalive + stale room sweep
setInterval(() => {
  for (const ws of wss.clients) { if (!ws.cbAlive) { try { ws.terminate(); } catch (e) {} continue; } ws.cbAlive = false; try { ws.ping(); } catch (e) {} }
  for (const r of rooms.values()) if (!r.all().length || (!r.started && Date.now() - r.madeAt > 6 * 3600e3)) r.close('Room expired');
}, 25000);

const HOST = process.env.HOST || '0.0.0.0';
server.listen(PORT, HOST, () => console.log(`Counter Brick server on ${HOST}:${PORT} — game at /, lobby at /ws`));
// a restart (deploy, reboot) tells every room why it ended instead of just dropping the sockets
for (const sig of ['SIGTERM', 'SIGINT']) process.on(sig, () => {
  for (const r of [...rooms.values()]) r.close('The game server is restarting');
  server.close(() => process.exit(0)); setTimeout(() => process.exit(0), 1500).unref();
});
