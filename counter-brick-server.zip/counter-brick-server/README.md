# Counter Brick game server

One small Node.js process that does three jobs:

1. **Serves the game** (`public/counter-brick.html`, one self-contained page, gzipped to about 0.4 MB).
2. **Runs the lobby**: rooms with 4-letter codes and invite links, 2 to 10 players each.
3. **Relays match traffic** between the room host and the other players over WebSockets (`/ws`).

The server never simulates the game. The room host's browser runs the match (bots, damage,
economy, rounds) exactly like single player; everyone else sends inputs and plays back the
host's state. That keeps the server tiny: the smallest AWS machine is plenty.

```
players' browsers ──https/wss──▶ Caddy (TLS) ──▶ node server.js :8080
                                                   ├─ GET /        the game page
                                                   ├─ GET /health  {"ok":true,"rooms":…,"players":…}
                                                   └─ WS  /ws      lobby + relay
```

## What is in this bundle

| File | What it is |
|---|---|
| `server.js` | The whole server (one dependency: `ws`) |
| `public/counter-brick.html` | The game, build shown on its main menu |
| `package.json`, `package-lock.json` | Dependency pin |
| `deploy/setup.sh` | One-shot install on a fresh Ubuntu machine (Node, Caddy, service) |
| `deploy/update.sh` | Put a newer bundle live: saves the old one, checks health, rolls back by itself if the new one fails |
| `deploy/rollback.sh` | Go back to an earlier version by hand (installed to `/opt/counter-brick/deploy/`) |
| `deploy/autoupdate.sh`, `deploy/setup-autoupdate.sh` | Hands-off updates: the server watches a release feed and installs newer builds itself |
| `deploy/setup-feedback.sh` | Copy player feedback to a private GitHub repo (asks for a token; stored root-only on the server) |
| `deploy/push.ps1`, `deploy/push.sh` | Run on YOUR computer (Windows / Mac / Linux): upload the zip and run `update.sh` for you |
| `Dockerfile`, `docker-compose.yml` | Container route, if you prefer Docker |

## Try it on your own computer first (2 minutes)

```bash
npm install
node server.js
```

Open `http://localhost:8080` in two browser windows. In one: **Play online → Host a game**.
In the other: **Play online**, type the code, **Join**. Back in the first: **Start the match**.

## Deploy on AWS: Lightsail (recommended, about 15 minutes)

A Lightsail instance is a plain Linux machine at a flat monthly price with a fixed IP address.
The $5/month plan (public IPv4) is enough.

1. **Create the machine.** Lightsail console → *Create instance* → Linux/Unix → *OS Only* →
   **Ubuntu 24.04 LTS** → the $5 plan with IPv4. Pick the region closest to your players
   (N. Virginia, `us-east-1`, for the US east coast): everything a player sees passes through
   this machine, so distance is latency.
2. **Give it a fixed address.** Instance → *Networking* → *Attach static IP* (free while attached).
3. **Open the web ports.** Same tab, *IPv4 firewall*: make sure **HTTP 80** is listed and add
   **HTTPS 443**. Leave SSH 22.
4. **(For HTTPS) point a name at it.** In your DNS, add an `A` record such as
   `play.yourdomain.com` → the static IP. Skip this to start on plain `http://`.
5. **Upload and install.** From your computer, with the SSH key Lightsail gave you:

   ```bash
   scp -i LightsailKey.pem counter-brick-server.zip ubuntu@<static-ip>:~
   ssh -i LightsailKey.pem ubuntu@<static-ip>
   sudo apt-get install -y unzip && unzip -o counter-brick-server.zip && cd counter-brick-server
   sudo bash deploy/setup.sh play.yourdomain.com     # or:  sudo bash deploy/setup.sh   (http only)
   ```

   The script installs Node.js and Caddy, runs the server as a service (restarts on failure and
   on reboot), and puts Caddy in front. With a domain name, Caddy gets and renews the HTTPS
   certificate by itself; the name must already point at the machine when you run the script.
6. **Play.** Open `https://play.yourdomain.com/` → **Play online → Host a game → Copy invite link**
   and send the link to your friends.

**http or https?** Both run the game. Use https for real play: browsers only allow the
one-tap invite-link copy and the full-screen keyboard lock on secure pages, and some networks
interfere with unencrypted WebSockets.

### Other AWS routes

- **EC2**: identical to the above. Launch Ubuntu 24.04 (a `t4g.micro`/`t3.micro` is enough),
  allow inbound 80 and 443 in the security group, attach an Elastic IP, run `deploy/setup.sh`.
- **Docker** (any machine with Docker): `DOMAIN=play.yourdomain.com docker compose up -d --build`.
- **ECS / Elastic Beanstalk behind an Application Load Balancer**: works (the ALB passes
  WebSockets through); terminate TLS on the ALB with an ACM certificate and health-check `/health`.
- **App Runner: do not use.** It does not support WebSocket connections.

**Run exactly one copy.** Rooms live in this process's memory, so two instances behind a load
balancer would put the host and a joiner on different machines. One instance handles far more
rooms than a friends' server will ever see (limit: 200 rooms, 10 players each).

## Putting a new game build live

**From your own computer (the normal way).** Download `counter-brick-server.zip`, unzip it somewhere
(or just keep the zip), and from that folder run:

```powershell
.\deploy\push.ps1                      # Windows PowerShell; Mac/Linux/Git Bash: bash deploy/push.sh
.\deploy\push.ps1 C:\path\to\counter-brick-server.zip     # if it cannot find the zip by itself
```

The first run asks for the server address, SSH user and key path, and remembers them
(`%USERPROFILE%\.counter-brick-push.json`). Every later push is the one command. It uploads the zip,
unpacks it on the server and runs `update.sh`.

**What `update.sh` does** (also works by hand: unzip on the server, `sudo bash deploy/update.sh`):

1. Saves the version that is live now under `/opt/counter-brick/releases/` (the last 8 are kept).
2. Installs the new page. If `server.js` or the lockfile changed it also reinstalls dependencies and
   restarts the service; if only the page changed there is no restart and nobody is interrupted.
3. Asks `/health` which build is being served. If it is not the new one within about 20 seconds it
   puts the previous version back by itself, prints `ROLLED BACK`, and exits with an error.

Players get the new build on their next page load; rooms already in a match keep the page they loaded.
A restart (server change) closes open rooms and tells the players why.

**Hands-off (no push at all).** Turn on automatic updates once and the server looks after itself:

```bash
sudo bash /opt/counter-brick/deploy/setup-autoupdate.sh https://raw.githubusercontent.com/<owner>/<repo>/main
```

The address is a folder on the web with two files: `latest.json` (build number + checksum) and
`counter-brick-server.zip`. When a newer build appears the server downloads it, checks the checksum,
and installs it through `update.sh` (so: saved copy, health check, automatic rollback). It checks once a
minute; allow a few minutes for GitHub's own caching. A build that failed to start is rolled back and not
retried; a build you rolled back from by hand is not pushed again. Check what it did with
`journalctl -u counter-brick-autoupdate -n 20`; turn it off with `... setup-autoupdate.sh off`.
Publishing to the feed is `bash tools/publish-feed.sh <feed repo folder>` in the source tree.

**Going back by hand:**

```bash
sudo /opt/counter-brick/deploy/rollback.sh          # list saved versions
sudo /opt/counter-brick/deploy/rollback.sh last     # the version before the latest update
```

`https://<your-name>/health` shows the build being served, for example `"build":"v32"`.

## Player feedback

The in-game **Send feedback** form posts to `/feedback`. Every message is kept in
`/opt/counter-brick/data/feedback.jsonl` (updates and rollbacks never touch `data/`). To have messages copied
to a private GitHub repo as they arrive:

1. Create a private repo, e.g. `counter-brick-feedback`.
2. Create a fine-grained token (GitHub > Settings > Developer settings > Fine-grained tokens): only that repo,
   permission **Contents: Read and write**.
3. On the server: `sudo bash /opt/counter-brick/deploy/setup-feedback.sh <owner>/counter-brick-feedback` and paste
   the token when asked (it is not shown, and is stored root-only in `/etc/counter-brick/feedback.env`).

Messages that arrived earlier are copied too. If GitHub is down, they wait and are copied later.
`/health` shows `"feedback":{"stored":N,"github":"up to date"}`. Turn copying off with `... setup-feedback.sh off`.
Limits: 5 messages per address per 10 minutes, 4000 characters each.

**Dashboard:** open `https://<your-name>/feedback/admin` and enter the owner password. Mark messages, feature the
good ones to players (they rotate on the title screen), copy everything for Claude, or download JSON. Statuses
live in `/opt/counter-brick/data/feedback-status.json`. To change the password, set
`CB_OWNER_KEY_SHA256=<sha256 of the new password>` in the service environment (for example, as an extra line in
`/etc/counter-brick/feedback.env` once `setup-feedback.sh` has created it) and restart the service.

## Looking after it

| Task | Command |
|---|---|
| Is it up? | `curl http://127.0.0.1:8080/health` (also reachable as `https://<your-name>/health`) |
| Live log | `journalctl -u counter-brick -f` |
| Restart | `sudo systemctl restart counter-brick` |
| HTTPS problems | `journalctl -u caddy -n 50` (usually: DNS not pointing here yet, or port 443 closed) |

Settings are environment variables: `PORT` (8080), `HOST` (0.0.0.0; the setup script binds it
to 127.0.0.1 behind Caddy), `CB_PUBLIC` (folder holding `counter-brick.html`).

## How online play behaves (worth telling your players)

- **The host's computer runs the match.** The best experience comes from the player with the
  strongest computer and connection hosting. If the host closes the page, the room ends for
  everyone; if any other player leaves, the match carries on without them.
- **Teams** alternate by join order (host's team, other team, host's team, …) and are shown in
  the lobby before the start. Bots fill empty slots up to the team sizes the host set.
- **The host picks** map, mode (Bomb or Heist), match length, bot difficulty and starting side on
  the normal setup screen before pressing *Play online*; "Play again" on the results screen
  starts a rematch for the whole room.
- **A room locks when the match starts.** Late arrivals wait for the next room.
- **Tabbing away is safe**: the match keeps running on a hidden tab (host or player).
- **Built for friends.** Hits, money and round results are decided on the host, but each
  player's own movement is trusted, and a dishonest host could cheat. There is no account
  system and no matchmaking: a room is reachable only by its code or invite link.
- **Everyone must load the game from this server** so all players run the same build. The page
  is always re-checked on load, so a refresh is the fix for any "version" oddness.
